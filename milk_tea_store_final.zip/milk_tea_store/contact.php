<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liên hệ - Milk Tea Store</title>
    
    <!-- Link đến file CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=1.2">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <main>
        <section class="contact-form">
            <h1>Liên hệ với chúng tôi</h1>
            <p>Vui lòng điền thông tin của bạn vào mẫu dưới đây và chúng tôi sẽ liên hệ lại với bạn trong thời gian sớm nhất.</p>
            <form action="process_contact.php" method="POST">
                <label>Tên của bạn: <input type="text" name="name" required></label><br>
                <label>Email: <input type="email" name="email" required></label><br>
                <label>Thông điệp: <textarea name="message" required></textarea></label><br>
                <button type="submit" class="btn-primary">Gửi</button>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
