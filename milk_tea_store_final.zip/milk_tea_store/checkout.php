<?php
session_start();
require 'includes/db_connection.php';

if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    $user_id = $_SESSION['user']['id'];
    $total_amount = 0;

    // Tính tổng số tiền
    foreach ($_SESSION['cart'] as $item_id => $item) {
        $total_amount += $item['product_price'] * $item['quantity'];
    }

    // Tạo đơn hàng mới
    $sql = "INSERT INTO orders (user_id, total_amount) VALUES ($user_id, $total_amount)";
    if ($conn->query($sql) === TRUE) {
        $order_id = $conn->insert_id;

        // Thêm sản phẩm vào order_items
        foreach ($_SESSION['cart'] as $item_id => $item) {
            $product_name = $conn->real_escape_string($item['product_name']);
            $product_price = $item['product_price'];
            $quantity = $item['quantity'];
            $sql = "INSERT INTO order_items (order_id, product_name, product_price, quantity) 
                    VALUES ($order_id, '$product_name', $product_price, $quantity)";
            $conn->query($sql);
        }

        // Cập nhật số lượng trong kho
        foreach ($_SESSION['cart'] as $item_id => $item) {
            $quantity = $item['quantity'];
            $sql = "UPDATE products SET stock_quantity = stock_quantity - $quantity WHERE id = $item_id";
            $conn->query($sql);
        }

        // Xóa giỏ hàng sau khi thanh toán thành công
        unset($_SESSION['cart']);

        // Chuyển hướng đến trang giỏ hàng với thông báo thanh toán thành công
        $_SESSION['message'] = "Thanh toán thành công!";
        header('Location: cart.php');
        exit();
    } else {
        // Xử lý lỗi nếu có
        echo "Lỗi: " . $conn->error;
    }
} else {
    // Xử lý trường hợp giỏ hàng rỗng
    $_SESSION['message'] = "Giỏ hàng rỗng!";
    header('Location: cart.php');
    exit();
}
?>
