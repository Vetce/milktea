<?php
session_start();

// Hủy session để đăng xuất
session_unset();
session_destroy();

// Chuyển hướng về trang chủ
header("Location: index.php");
exit();
?>
