<?php
session_start();

// Kiểm tra xem sản phẩm có được gửi đến hay không
if (isset($_POST['product_id']) && isset($_POST['product_name']) && isset($_POST['product_price'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];

    // Kiểm tra nếu giỏ hàng chưa tồn tại trong session, tạo mới
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['product_id'] == $product_id) {
            $item['quantity'] += 1; // Tăng số lượng sản phẩm nếu đã có
            $found = true;
            break;
        }
    }

    // Nếu sản phẩm chưa có trong giỏ hàng, thêm mới
    if (!$found) {
        $_SESSION['cart'][] = array(
            'product_id' => $product_id,
            'product_name' => $product_name,
            'product_price' => $product_price,
            'quantity' => 1
        );
    }

    // Quay lại trang sản phẩm hoặc giỏ hàng
    header("Location: product_page.php"); // Hoặc bạn có thể chuyển đến trang giỏ hàng.
    exit();
}
?>
