<header>
    <div class="logo">
        <img src="assets/images/logo.png" alt="Milk Tea Store">
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="cart.php">Giỏ hàng</a></li>
            <li><a href="contact.php">Liên hệ</a></li>
            <!-- Thêm các liên kết như Đăng nhập/Đăng ký nếu người dùng chưa đăng nhập -->
            <?php if (!isset($_SESSION['user_id'])): ?>
                <li><a href="login.php">Đăng nhập</a></li>
                <li><a href="register.php">Đăng ký</a></li>
            <?php else: ?>
                <li><a href="logout.php">Đăng xuất</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
