<?php
include 'includes/db_connection.php'; // Kết nối cơ sở dữ liệu

// Kiểm tra xem dữ liệu từ form đã được gửi hay chưa
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy giá trị từ form
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    // Kiểm tra nếu các trường cần thiết còn thiếu
    if (empty($username) || empty($password) || empty($email)) {
        echo "Vui lòng nhập đầy đủ thông tin!";
    } else {
        // Mã hóa mật khẩu trước khi lưu vào CSDL
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Câu lệnh SQL để thêm dữ liệu người dùng vào CSDL
        $sql = "INSERT INTO user (username, password, email) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Prepare failed: " . $conn->error); // Hiển thị lỗi nếu chuẩn bị câu lệnh thất bại
        }

        $stmt->bind_param("sss", $username, $hashed_password, $email); // Liên kết tham số

        if ($stmt->execute()) {
            echo "Đăng ký thành công!";
        } else {
            echo "Lỗi: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>
