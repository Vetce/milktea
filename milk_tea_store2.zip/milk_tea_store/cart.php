<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <h1>Giỏ hàng của bạn</h1>
    <p>Hiện tại không có sản phẩm nào trong giỏ hàng.</p>
    
    <?php include('includes/footer.php'); ?>
</body>
</html>
