<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Milk Tea Store</title>
    
    <!-- Link đến file CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=1.2">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php
    include('includes/db_connection.php');  // Kết nối cơ sở dữ liệu
    include('includes/header.php');        // Header (logo, menu)
    ?>

    <main>
        <!-- Banner -->
        <section class="banner">
            <div class="banner-text">
                <h1>Chào mừng đến với Milk Tea Store</h1>
                <p>Trà sữa ngon nhất, giá tốt nhất!</p>
                <a href="contact.php" class="btn-primary">Liên hệ ngay</a>
            </div>
        </section>

        <!-- Danh sách sản phẩm -->
        <section class="product-list">
            <h2>Sản phẩm nổi bật</h2>
            <div class="product-container">
                <?php
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $image = (!empty($row["image"])) ? $row["image"] : 'default.jpg'; // Ảnh mặc định
                        echo "<div class='product-item'>";
                        echo "<img src='assets/images/" . $image . "' alt='" . htmlspecialchars($row["name"], ENT_QUOTES) . "'>";
                        echo "<h3>" . htmlspecialchars($row["name"], ENT_QUOTES) . "</h3>";
                        echo "<p>" . htmlspecialchars($row["description"], ENT_QUOTES) . "</p>";
                        echo "<p><strong>" . number_format($row["price"], 0, ',', '.') . " VNĐ</strong></p>";
                        echo "<button class='btn-secondary'>Add to Cart</button>";
                        echo "</div>";
                    }
                } else {
                    echo "<p class='no-products'>Không có sản phẩm nào!</p>";
                }
                ?>
            </div>
        </section>

        <!-- Phần đăng ký -->
        <section class="register-form">
            <h2>Đăng ký tài khoản</h2>
            <form action="register.php" method="POST">
                <label for="username">Tên đăng nhập:</label>
                <input type="text" id="username" name="username" placeholder="Nhập tên đăng nhập" required>
                <br>

                <label for="password">Mật khẩu:</label>
                <input type="password" id="password" name="password" placeholder="Nhập mật khẩu" required>
                <br>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Nhập email" required>
                <br>

                <button type="submit">Đăng ký</button>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
