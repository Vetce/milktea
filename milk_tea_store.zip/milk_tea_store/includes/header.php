<header>
    <div class="logo">
        <img src="assets/images/logo.png" alt="Milk Tea Store">
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="cart.php">Giỏ hàng</a></li>
            <li><a href="contact.php">Liên hệ</a></li>
        </ul>
    </nav>
</header>
