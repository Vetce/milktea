<footer>
    <p>&copy; 2024 Milk Tea Store. Tất cả quyền được bảo vệ.</p>
</footer>
