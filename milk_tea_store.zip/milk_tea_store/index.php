<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Milk Tea Store</title>
    
    <!-- Thêm link đến file CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Thêm icon trang web (tùy chọn) -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

</head>
<body>

    <?php
    include('includes/db_connection.php');  // Kết nối cơ sở dữ liệu
    include('includes/header.php');  // Header (logo, thanh menu...)
    ?>

    <div class="product-list">
        <?php
        // Truy vấn dữ liệu sản phẩm từ cơ sở dữ liệu
        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);

        // Kiểm tra và hiển thị sản phẩm
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='product-item'>";
                echo "<h3>" . $row["name"] . "</h3>";
                echo "<img src='assets/images/" . $row["image"] . "' alt='" . $row["name"] . "'>";
                echo "<p>" . $row["description"] . "</p>";
                echo "<p><strong>" . $row["price"] . " VNĐ</strong></p>";
                echo "<button>Add to Cart</button>";
                echo "</div>";
            }
        } else {
            echo "Không có sản phẩm nào!";
        }
        ?>
    </div>

    <?php include('includes/footer.php');  // Footer ?>

</body>
</html>
