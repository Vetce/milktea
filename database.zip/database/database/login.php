<?php
session_start();
require 'includes/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            //save
            $_SESSION['user'] = $user;
            header("Location: index.php");
            exit();
        } else {
            $error = "Sai mật khẩu!";
        }
    } else {
        $error = "Sai tên đăng nhập!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - Milk Tea Store</title>
    
    <!-- file CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=1.2">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <main>
        <section class="login-form">
            <h1>Đăng nhập</h1>
            <?php 
            if (isset($_SESSION['message'])) { 
                echo "<p class='success'>" . $_SESSION['message'] . "</p>"; 
                unset($_SESSION['message']);
            }
            if (isset($error)) { 
                echo "<p class='error'>$error</p>"; 
            } 
            ?>
            <form method="POST" action="login.php">
                <label>Username: <input type="text" name="username" required></label><br>
                <label>Password: <input type="password" name="password" required></label><br>
                <button type="submit" class="btn-primary">Đăng nhập</button>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
