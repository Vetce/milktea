<?php
session_start();

//check san pham
if (isset($_POST['product_id']) && isset($_POST['product_name']) && isset($_POST['product_price'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];

    //check gio hang chua ton tai
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    //check gio hang ton tai
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['product_id'] == $product_id) {
            $item['quantity'] += 1; 
            $found = true;
            break;
        }
    }

    //them san pham
    if (!$found) {
        $_SESSION['cart'][] = array(
            'product_id' => $product_id,
            'product_name' => $product_name,
            'product_price' => $product_price,
            'quantity' => 1
        );
    }


    header("Location: product_page.php"); 
    exit();
}
?>
