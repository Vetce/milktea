<?php
session_start();  // Bắt đầu session để lưu trữ giỏ hàng

// "Add to Cart"
if (isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];  // ID sản phẩm
    $quantity = 1;  //default

    //connnect database
    include('includes/db_connection.php');
    $sql = "SELECT * FROM products WHERE id = $product_id";
    $result = $conn->query($sql);
    $product = $result->fetch_assoc();

    //add to carrt
    if ($product) {
        //checking
        if (!isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id] = [
                'product_name' => $product['name'],
                'product_price' => $product['price'],
                'quantity' => $quantity
            ];
        } else {
            // + 1
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        }
    }

    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Milk Tea Store</title>
    
    <!-- file CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=1.2">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php
    include('includes/db_connection.php');  //connect database
    include('includes/header.php');       
    ?>

    <main>
        <!-- Banner -->
        <section class="banner">
            <div class="banner-text">
                <h1>Chào mừng đến với Milk Tea Store</h1>
                <p>Trà sữa ngon nhất, giá tốt nhất!</p>
                <a href="contact.php" class="btn-primary">Liên hệ ngay viện trí tuệ nhân tạo</a>
            </div>
        </section>

        <!-- Danh sách sản phẩm -->
        <section class="product-list">
            <h2>Sản phẩm nổi bật</h2>
            <div class="product-container">
                <?php
                $sql = "SELECT * FROM products";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $image = (!empty($row["image"])) ? $row["image"] : 'default.jpg'; // Ảnh mặc định
                        echo "<div class='product-item'>";
                        echo "<img src='assets/images/" . $image . "' alt='" . htmlspecialchars($row["name"], ENT_QUOTES) . "'>";
                        echo "<h3>" . htmlspecialchars($row["name"], ENT_QUOTES) . "</h3>";
                        echo "<p>" . htmlspecialchars($row["description"], ENT_QUOTES) . "</p>";
                        echo "<p><strong>" . $row["price"] . " VNĐ</strong></p>";

                        //send to gio hang
                        echo "<form action='index.php' method='POST'>";
                        echo "<input type='hidden' name='product_id' value='" . $row['id'] . "'>";
                        echo "<button type='submit' name='add_to_cart' class='btn-secondary'>Add to Cart</button>";
                        echo "</form>";

                        echo "</div>";
                    }
                } else {
                    echo "<p class='no-products'>Không có sản phẩm nào!</p>";
                }
                ?>
            </div>
        </section>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
