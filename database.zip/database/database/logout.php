<?php
session_start();

//logout
session_unset();
session_destroy();

//trang chu
header("Location: index.php");
exit();
?>
