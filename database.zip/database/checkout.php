<?php
session_start();
require 'includes/db_connection.php';

if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
    $user_id = $_SESSION['user']['id'];
    $total_amount = 0;
    $address = $conn->real_escape_string($_POST['address']); // Lấy địa chỉ từ form

    //tong tien
    foreach ($_SESSION['cart'] as $item_id => $item) {
        $total_amount += $item['product_price'] * $item['quantity'];
    }

    //new order + dia chi
    $sql = "INSERT INTO orders (user_id, total_amount, address) VALUES ($user_id, $total_amount, '$address')";
    if ($conn->query($sql) === TRUE) {
        $order_id = $conn->insert_id;

        //them vao phan order_item
        foreach ($_SESSION['cart'] as $item_id => $item) {
            $product_name = $conn->real_escape_string($item['product_name']);
            $product_price = $item['product_price'];
            $quantity = $item['quantity'];
            $sql = "INSERT INTO order_items (order_id, product_name, product_price, quantity) 
                    VALUES ($order_id, '$product_name', $product_price, $quantity)";
            $conn->query($sql);
        }

        //update hang ton kho
        foreach ($_SESSION['cart'] as $item_id => $item) {
            $quantity = $item['quantity'];
            $sql = "UPDATE products SET stock_quantity = stock_quantity - $quantity WHERE id = $item_id";
            $conn->query($sql);
        }

        //delete cart
        unset($_SESSION['cart']);

        $_SESSION['message'] = "Thanh toán thành công!";
        header('Location: cart.php');
        exit();
    } else {
        echo "Lỗi: " . $conn->error;
    }
} else {
    $_SESSION['message'] = "Giỏ hàng rỗng!";
    header('Location: cart.php');
    exit();
}
?>
