<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>
    
    <h1>Giỏ hàng của bạn</h1>

    <?php
    session_start(); // Khởi tạo session để truy cập giỏ hàng

    // Hiển thị thông báo nếu có
    if (isset($_SESSION['message'])) {
        echo "<p class='success-message'>" . $_SESSION['message'] . "</p>";
        unset($_SESSION['message']); // Xóa thông báo sau khi hiển thị
    }

    // Kiểm tra nếu giỏ hàng không trống
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        echo "<table>";
        echo "<tr><th>Sản phẩm</th><th>Giá</th><th>Số lượng</th><th>Tổng cộng</th><th>Hành động</th></tr>";

        $total = 0;  // Biến lưu tổng tiền của giỏ hàng

        // Duyệt qua các sản phẩm trong giỏ hàng
        foreach ($_SESSION['cart'] as $key => $item) {
            // Tính tổng tiền cho mỗi sản phẩm
            $item_total = $item['product_price'] * $item['quantity'];
            $total += $item_total;  // Cộng tổng tiền của sản phẩm vào tổng giỏ hàng

            echo "<tr>";
            echo "<td>" . htmlspecialchars($item['product_name'], ENT_QUOTES) . "</td>";
            echo "<td>" . number_format($item['product_price'], 0, ',', '.') . " VNĐ</td>"; // Hiển thị giá gốc
            echo "<td>" . $item['quantity'] . "</td>";
            echo "<td>" . number_format($item_total, 0, ',', '.') . " VNĐ</td>"; // Hiển thị tổng tiền của sản phẩm
            echo "<td><a href='remove_from_cart.php?id=" . $key . "'>Xóa</a></td>"; // Liên kết xóa sản phẩm
            echo "</tr>";
        }

        // Hiển thị tổng tiền của giỏ hàng
        echo "<tr><td colspan='4' style='text-align: right;'><strong>Tổng cộng:</strong></td><td><strong>" . number_format($total, 0, ',', '.') . " VNĐ</strong></td></tr>";
        echo "</table>";

        // Form nhập địa chỉ và nút thanh toán
        echo '<form action="checkout.php" method="POST">';
        echo '<label for="address">Địa chỉ giao hàng:</label><br>';
        echo '<input type="text" id="address" name="address" required><br><br>';
        echo '<button type="submit" class="checkout-btn">Thanh toán</button>';
        echo '</form>';
    } else {
        echo "<p>Hiện tại không có sản phẩm nào trong giỏ hàng.</p>";
    }
    ?>

    <?php include('includes/footer.php'); ?>
</body>
</html>
