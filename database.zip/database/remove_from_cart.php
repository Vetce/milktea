<?php
session_start();

// Kiểm tra nếu giỏ hàng có tồn tại
if (isset($_SESSION['cart'])) {
    // Kiểm tra xem ID sản phẩm có được gửi đến không
    if (isset($_GET['id'])) {
        $product_id = $_GET['id'];

        // Xóa sản phẩm theo ID
        unset($_SESSION['cart'][$product_id]);

        // Chuyển hướng lại trang giỏ hàng
        header("Location: cart.php");
        exit();
    }
}

// Nếu giỏ hàng trống, chuyển về trang giỏ hàng
header("Location: cart.php");
exit();
?>
