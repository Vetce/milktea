<?php
session_start();

//check cart
if (isset($_SESSION['cart'])) {
    //check id
    if (isset($_GET['id'])) {
        $product_id = $_GET['id'];

        //delete
        unset($_SESSION['cart'][$product_id]);

        header("Location: cart.php");
        exit();
    }
}

header("Location: cart.php");
exit();
?>
