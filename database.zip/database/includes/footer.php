<footer>
    <p>&copy; 2024 Milk Tea Store. Nơi đây có bán trà sữa ngon hơn người yêu cũ của bạn.</p>
</footer>
