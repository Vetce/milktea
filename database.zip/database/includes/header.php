<header>
    <div class="logo">
        <img src="assets/images/logo.png" alt="Milk Tea Store">
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Trang chủ</a></li>
            <li><a href="cart.php">Giỏ hàng</a></li>
            <li><a href="contact.php">Liên hệ</a></li>

            <?php if (!isset($_SESSION['user'])): ?>
                <!-- Nếu người dùng chưa đăng nhập, hiển thị các liên kết đăng nhập và đăng ký -->
                <li><a href="login.php">Đăng nhập</a></li>
                <li><a href="register.php">Đăng ký</a></li>
            <?php else: ?>
                <!-- Nếu người dùng đã đăng nhập, hiển thị tên người dùng và nút đăng xuất -->
                <li class="username"><?php echo $_SESSION['user']['username']; ?></li>
                <li><a href="logout.php">Đăng xuất</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
