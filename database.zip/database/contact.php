<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liên hệ - Milk Tea Store</title>
    
    <!-- file CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=1.2">

    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Header -->
    <?php include('includes/header.php'); ?>

    <main>
        <section class="contact-form">
            <h1>Liên hệ với chúng tôi</h1>
            <p>Liên hệ chúng tôi qua SĐT: 0xxxxxxxxx</p>
            <p>Email: UET@2024.gmail.com</p>
        </section>
    </main>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</body>
</html>
